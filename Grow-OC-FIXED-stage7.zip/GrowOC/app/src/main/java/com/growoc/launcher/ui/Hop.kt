package com.growoc.launcher.ui

import android.content.Context
import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import com.growoc.launcher.data.K
import com.growoc.launcher.data.save
import com.growoc.launcher.data.update
import com.growoc.launcher.pet.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

private fun animatorScale(ctx: Context): Float =
    Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)

/**
 * HOP drawn with vector shapes. live = false is the cheap mode used in the Island pill:
 * no frame loop, just a rare blink. The frame loop runs only while the HOP panel is open.
 */
@Composable
fun HopView(
    pr: Preferences, charging: Boolean, live: Boolean,
    modifier: Modifier = Modifier, cmd: Pair<HopAct, Int> = HopAct.IDLE to 0
) {
    val ctx = LocalContext.current
    val minute by produceState(0) { while (true) { delay(60_000L); value = value + 1 } }
    val color = HopColor.values().firstOrNull { it.name == pr[K.HOP_COLOR] } ?: HopColor.GINGER
    val stats = remember(pr, minute) { HopStore.stats(pr) }
    val sleeping = remember(pr, minute) { HopStore.sleeping(pr) }
    val animOn = (pr[K.HOP_ANIM] ?: true) && live && animatorScale(ctx) > 0f
    val react = pr[K.HOP_CHARGE] ?: true
    val glowK = (pr[K.HOP_GLOW] ?: 70) / 100f
    val mood = HopLogic.moodOf(stats)
    val base = when {
        sleeping -> HopAct.SLEEP
        mood == HopMood.SLEEPY -> HopAct.TIRED
        mood == HopMood.IRRITATED -> HopAct.ANNOYED
        else -> HopAct.IDLE
    }
    var shot by remember { mutableStateOf<HopAct?>(null) }
    val time = remember { mutableFloatStateOf(0f) }
    val shotStart = remember { mutableFloatStateOf(0f) }
    var blink by remember { mutableStateOf(false) }
    val charge = animateFloatAsState(if (charging && react) 1f else 0f, tween(900), label = "charge")

    LaunchedEffect(animOn) {
        if (!animOn) return@LaunchedEffect
        val t0 = withFrameNanos { it }
        while (true) withFrameNanos { time.floatValue = (it - t0) / 1_000_000_000f }
    }
    LaunchedEffect(sleeping) {
        while (!sleeping) {
            delay(Random.nextLong(2800L, 6000L)); blink = true
            delay(140L); blink = false
        }
    }
    LaunchedEffect(animOn, base) {
        if (!animOn || base != HopAct.IDLE) return@LaunchedEffect
        while (true) {
            delay(Random.nextLong(7000L, 15000L))
            if (shot == null) {
                val act = listOf(HopAct.WALK, HopAct.JUMP, HopAct.STRETCH).random()
                shot = act; shotStart.floatValue = time.floatValue
                delay((act.duration() * 1000f).toLong())
                shot = null
            }
        }
    }
    LaunchedEffect(cmd) {
        if (cmd.second > 0) {
            shot = cmd.first; shotStart.floatValue = time.floatValue
            delay((cmd.first.duration() * 1000f).toLong().coerceAtLeast(400L))
            shot = null
        }
    }

    Canvas(modifier) {
        val tm = time.floatValue
        val pose = hopPose(shot ?: base, tm, (tm - shotStart.floatValue).coerceAtLeast(0f), blink, charge.value)
        drawHop(color, pose, glowK, tm)
    }
}

@Composable
fun HopPanel(pr: Preferences, charging: Boolean) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var cmd by remember { mutableStateOf(HopAct.IDLE to 0) }
    var more by remember { mutableStateOf(false) }
    var nameField by remember(pr[K.HOP_NAME]) { mutableStateOf(pr[K.HOP_NAME] ?: "HOP") }
    val stats = HopStore.stats(pr)
    val sleeping = HopStore.sleeping(pr)
    val name = pr[K.HOP_NAME] ?: "HOP"
    fun act(a: HopAct) { cmd = a to cmd.second + 1 }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        HopView(
            pr, charging, true,
            Modifier.fillMaxWidth().height(190.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                scope.launch {
                    if (sleeping) {
                        if (pr[K.HOP_WAKE_TOUCH] ?: true) { HopStore.wake(ctx); act(HopAct.WAKE) }
                    } else {
                        HopStore.put(ctx, HopLogic.pet(stats)); act(HopAct.HAPPY)
                    }
                }
            },
            cmd
        )
        Text(
            name + " · " + HopLogic.moodOf(stats).name.lowercase().replaceFirstChar { it.uppercase() },
            color = p.text, fontWeight = FontWeight.SemiBold
        )
        Bar("Hunger", stats.hunger, Color(0xFFE9893B))
        Bar("Energy", stats.energy, Color(0xFF34C759))
        Bar("Happiness", stats.happiness, Color(0xFFFF6B8B))
        Bar("Mood", HopLogic.mood(stats), p.accent)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Feed") { scope.launch { HopStore.put(ctx, HopLogic.feed(stats)); act(HopAct.HAPPY) } }
            Chip("Play") {
                scope.launch {
                    val next = HopLogic.play(stats)
                    if (next == null) act(HopAct.TIRED) else { HopStore.put(ctx, next); act(HopAct.PLAY) }
                }
            }
            Chip(if (sleeping) "Wake" else "Sleep") {
                scope.launch {
                    if (sleeping) { HopStore.wake(ctx); act(HopAct.WAKE) }
                    else ctx.update { it[K.HOP_SLEEP_MANUAL] = true }
                }
            }
            Chip("Settings", more) { more = !more }
        }
        if (more) {
            Field(nameField, { nameField = it }, "Name")
            Chip("Save name") { scope.launch { ctx.save(K.HOP_NAME, nameField.trim().ifEmpty { "HOP" }) } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HopColor.values().forEach { c ->
                    Chip(c.label, pr[K.HOP_COLOR] == c.name || (pr[K.HOP_COLOR] == null && c == HopColor.GINGER)) {
                        scope.launch { ctx.save(K.HOP_COLOR, c.name) }
                    }
                }
            }
            ToggleRow("React to charging", pr[K.HOP_CHARGE] ?: true) { v -> scope.launch { ctx.save(K.HOP_CHARGE, v) } }
            ToggleRow("Glow inside the Island", pr[K.HOP_GLOW_INSIDE] ?: false) { v -> scope.launch { ctx.save(K.HOP_GLOW_INSIDE, v) } }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Glow", Modifier.weight(1f), color = p.text, fontSize = 15.sp)
                val g = pr[K.HOP_GLOW] ?: 70
                Chip("Low", g == 35) { scope.launch { ctx.save(K.HOP_GLOW, 35) } }
                Chip("Medium", g == 70) { scope.launch { ctx.save(K.HOP_GLOW, 70) } }
                Chip("High", g == 100) { scope.launch { ctx.save(K.HOP_GLOW, 100) } }
            }
            ToggleRow("Wake on touch", pr[K.HOP_WAKE_TOUCH] ?: true) { v -> scope.launch { ctx.save(K.HOP_WAKE_TOUCH, v) } }
            ToggleRow("Show HOP in the Island", pr[K.HOP_IN_ISLAND] ?: true) { v -> scope.launch { ctx.save(K.HOP_IN_ISLAND, v) } }
            ToggleRow("Animations", pr[K.HOP_ANIM] ?: true) { v -> scope.launch { ctx.save(K.HOP_ANIM, v) } }
            HourRow("Sleep from", pr[K.HOP_SLEEP_START] ?: 22) { h -> scope.launch { ctx.save(K.HOP_SLEEP_START, h) } }
            HourRow("Wake at", pr[K.HOP_WAKE_HOUR] ?: 7) { h -> scope.launch { ctx.save(K.HOP_WAKE_HOUR, h) } }
        }
    }
}

@Composable
private fun HourRow(label: String, hour: Int, onChange: (Int) -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = p.text, fontSize = 15.sp)
        Chip("−") { onChange((hour + 23) % 24) }
        Text("%02d:00".format(hour), color = p.text, modifier = Modifier.padding(horizontal = 12.dp))
        Chip("+") { onChange((hour + 1) % 24) }
    }
}
