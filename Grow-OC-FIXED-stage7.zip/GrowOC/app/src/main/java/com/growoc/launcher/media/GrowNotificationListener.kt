package com.growoc.launcher.media

import android.service.notification.NotificationListenerService

/**
 * Android requires an enabled notification listener before an app may read other apps'
 * media sessions. This service reads no notifications; it only unlocks MediaSessionManager.
 */
class GrowNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() { MediaRepo.start(applicationContext) }
    override fun onListenerDisconnected() { MediaRepo.stop() }
}
