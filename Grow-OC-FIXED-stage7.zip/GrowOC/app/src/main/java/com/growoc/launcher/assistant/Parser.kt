package com.growoc.launcher.assistant

/** Picks the reply language: ru, uk or anything else (English). */
fun tr(l: String, ru: String, uk: String, en: String): String =
    when (l.take(2)) { "ru" -> ru; "uk" -> uk; else -> en }

object Norm {
    private val junk = Regex("[^\\p{L}\\p{N}%.,:+\\-*/^()\\s]")
    private val ws = Regex("\\s+")
    fun text(s: String): String =
        s.lowercase().replace('ё', 'е').replace("'", "").replace("’", "").replace("ʼ", "")
            .replace(junk, " ").replace(ws, " ").trim()
}

/** Spoken numbers (ru, uk, en) to digits: "двадцать пять" -> "25". */
object Words {
    private val units: Map<String, Int> = (
        "ноль=0 нуль=0 один=1 одна=1 одно=1 одне=1 два=2 две=2 дві=2 три=3 четыре=4 чотири=4 пять=5 шесть=6 шість=6 " +
        "семь=7 сім=7 восемь=8 вісім=8 девять=9 десять=10 одиннадцать=11 одинадцять=11 двенадцать=12 дванадцять=12 " +
        "тринадцать=13 тринадцять=13 четырнадцать=14 чотирнадцять=14 пятнадцать=15 пятнадцять=15 шестнадцать=16 " +
        "шістнадцять=16 семнадцать=17 сімнадцять=17 восемнадцать=18 вісімнадцять=18 девятнадцать=19 девятнадцять=19 " +
        "двадцать=20 двадцять=20 тридцать=30 тридцять=30 сорок=40 пятьдесят=50 пятдесят=50 шестьдесят=60 шістдесят=60 " +
        "семьдесят=70 сімдесят=70 восемьдесят=80 вісімдесят=80 девяносто=90 сто=100 двести=200 двісті=200 триста=300 " +
        "четыреста=400 чотириста=400 пятьсот=500 пятсот=500 шестьсот=600 шістсот=600 семьсот=700 сімсот=700 " +
        "восемьсот=800 вісімсот=800 девятьсот=900 девятсот=900 " +
        "zero=0 one=1 two=2 three=3 four=4 five=5 six=6 seven=7 eight=8 nine=9 ten=10 eleven=11 twelve=12 thirteen=13 " +
        "fourteen=14 fifteen=15 sixteen=16 seventeen=17 eighteen=18 nineteen=19 twenty=20 thirty=30 forty=40 fifty=50 " +
        "sixty=60 seventy=70 eighty=80 ninety=90"
        ).split(' ').associate { val (w, n) = it.split('='); w to n.toInt() }

    private val mult = mapOf(
        "hundred" to 100, "thousand" to 1000, "тысяча" to 1000, "тысячи" to 1000, "тысяч" to 1000,
        "тисяча" to 1000, "тисячі" to 1000, "тисяч" to 1000
    )

    fun toDigits(text: String): String {
        val out = ArrayList<String>()
        var acc = -1L
        for (tok in text.split(' ')) {
            val v = units[tok]
            val m = mult[tok]
            if (v != null) {
                acc = if (acc >= 0L) acc + v else v.toLong()
            } else if (m != null) {
                acc = (if (acc >= 0L) acc else 1L) * m
            } else {
                if (acc >= 0L) { out.add(acc.toString()); acc = -1L }
                out.add(tok)
            }
        }
        if (acc >= 0L) out.add(acc.toString())
        return out.joinToString(" ")
    }
}

object History {
    fun add(old: String, cmd: String, max: Int = 20): String =
        (listOf(cmd) + old.split('\n').filter { it.isNotBlank() && it != cmd }).take(max).joinToString("\n")

    fun list(s: String?): List<String> = (s ?: "").split('\n').filter { it.isNotBlank() }
}

object GootParser {
    data class Parsed(val id: String?, val arg: String = "")

    private val names = setOf("goot", "гут", "гуд", "гоот")
    private val openVerbs = listOf("открой", "запусти", "відкрий", "open", "launch", "start")

    private val percentOf = Regex(
        "(\\d+(?:[.,]\\d+)?)\\s*(?:%|процентов|процента|процент|відсотків|відсотки|відсоток|percent)\\s*(?:от|від|of)\\s*(\\d+(?:[.,]\\d+)?)"
    )
    private val ops = listOf(
        "умножить на" to "*", "помножити на" to "*", "multiplied by" to "*", "multiply by" to "*",
        "умножь на" to "*", "times" to "*",
        "разделить на" to "/", "поділити на" to "/", "розділити на" to "/", "divided by" to "/", "divide by" to "/",
        "в степени" to "^", "у степені" to "^", "to the power of" to "^",
        "плюс" to "+", "plus" to "+", "минус" to "-", "мінус" to "-", "minus" to "-"
    )
    private val timeUnit = Regex("(\\d+)\\s*(час\\w*|годин\\w*|hour\\w*|hr|мин\\w*|хвилин\\w*|min\\w*|сек\\w*|sec\\w*)")
    private val hhmm = Regex("(\\d{1,2})[:.](\\d{2})")
    private val hourOnly = Regex("(?:на|at|о|в)\\s*(\\d{1,2})(?!\\d)")
    private val evening = Regex("вечер|вечора|pm")

    private fun stripName(t: String): String {
        val i = t.indexOf(' ')
        val first = if (i < 0) t else t.substring(0, i)
        return if (first in names) (if (i < 0) "" else t.substring(i + 1)) else t
    }

    fun parse(text: String, cmds: List<Cmd> = CommandRegistry.all): Parsed {
        val t = stripName(Norm.text(text))
        if (t.isEmpty()) return Parsed(null)
        var best: Cmd? = null
        var bestPhrase = ""
        var bestScore = 0
        for (c in cmds) for (p in c.norm) {
            val rank = when {
                t == p -> 3
                t.startsWith("$p ") -> 2
                t.endsWith(" $p") || t.contains(" $p ") -> 1
                else -> 0
            }
            if (rank == 0) continue
            val score = p.length * 4 + rank // longer (more specific) phrase wins
            if (score > bestScore) { best = c; bestPhrase = p; bestScore = score }
        }
        if (best != null) {
            val i = t.indexOf(bestPhrase)
            return Parsed(best.id, t.substring(i + bestPhrase.length).trim())
        }
        val verb = openVerbs.firstOrNull { t.startsWith("$it ") }
        if (verb != null) return Parsed("app.open", t.removePrefix(verb).trim())
        if (mathValue(t) != null) return Parsed("math", t)
        return Parsed(null)
    }

    /** Evaluates spoken or written math, e.g. "два плюс два", "20 процентов от 500". Null if not math. */
    fun mathValue(text: String): Double? {
        var s = Words.toDigits(Norm.text(text))
        s = percentOf.replace(s) { "(" + it.groupValues[1] + "/100*" + it.groupValues[2] + ")" }
        s = " $s "
        for ((a, b) in ops) s = s.replace(" $a ", " $b ")
        val expr = s.filter { it in "0123456789.,+-*/^()% " }.trim()
        if (!expr.any { it.isDigit() } || !expr.any { it in "+-*/^%" }) return null
        return Calc.eval(expr)
    }

    /** "на 10 минут" -> 600. Null when no duration is present. */
    fun seconds(text: String): Int? {
        val s = Words.toDigits(Norm.text(text))
        var total = 0L
        var found = false
        for (m in timeUnit.findAll(s)) {
            val n = m.groupValues[1].toLongOrNull() ?: continue
            val u = m.groupValues[2]
            total += n * when {
                u.startsWith("час") || u.startsWith("годин") || u.startsWith("hour") || u == "hr" -> 3600L
                u.startsWith("мин") || u.startsWith("хвилин") || u.startsWith("min") -> 60L
                else -> 1L
            }
            found = true
        }
        return if (found) total.coerceAtMost(86400L).toInt() else null
    }

    /** "на 7:30" -> (7, 30); "на 7 вечера" -> (19, 0). */
    fun clock(text: String): Pair<Int, Int>? {
        val s = Words.toDigits(Norm.text(text))
        val pm = evening.containsMatchIn(s)
        val a = hhmm.find(s)
        if (a != null) {
            val h = a.groupValues[1].toInt()
            val m = a.groupValues[2].toInt()
            if (h < 24 && m < 60) return (if (pm && h < 12) h + 12 else h) to m
        }
        val b = hourOnly.find(s)
        if (b != null) {
            val h = b.groupValues[1].toInt()
            if (h < 24) return (if (pm && h < 12) h + 12 else h) to 0
        }
        return null
    }
}
