package com.growoc.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

private val Context.store by preferencesDataStore("grow_prefs")

/** Local settings keys. Everything lives on-device in DataStore. */
object K {
    val ONBOARDED = booleanPreferencesKey("onboarded")
    val THEME = stringPreferencesKey("theme")          // "auto" or a palette id
    val COLUMNS = intPreferencesKey("columns")
    val HIDDEN = stringSetPreferencesKey("hidden")     // hidden only inside Grow OC
    val DOCK = stringPreferencesKey("dock")            // comma-separated packages
    // GOOT
    val GOOT_LANG = stringPreferencesKey("goot_lang")
    val GOOT_HISTORY = stringPreferencesKey("goot_history")
    val FAV_BLOGGER = stringPreferencesKey("fav_blogger")
    val FAV_SITE = stringPreferencesKey("fav_site")
    val FAV_APP = stringPreferencesKey("fav_app")
    val FAV_MUSIC = stringPreferencesKey("fav_music")
    // HOP
    val HOP_NAME = stringPreferencesKey("hop_name")
    val HOP_COLOR = stringPreferencesKey("hop_color")
    val HOP_HUNGER = intPreferencesKey("hop_hunger")
    val HOP_ENERGY = intPreferencesKey("hop_energy")
    val HOP_HAPPY = intPreferencesKey("hop_happy")
    val HOP_STAMP = longPreferencesKey("hop_stamp")
    val HOP_SLEEP_MANUAL = booleanPreferencesKey("hop_sleep_manual")
    val HOP_WOKEN_UNTIL = longPreferencesKey("hop_woken_until")
    val HOP_SLEEP_START = intPreferencesKey("hop_sleep_start")
    val HOP_WAKE_HOUR = intPreferencesKey("hop_wake_hour")
    val HOP_CHARGE = booleanPreferencesKey("hop_charge")
    val HOP_GLOW = intPreferencesKey("hop_glow")
    val HOP_GLOW_INSIDE = booleanPreferencesKey("hop_glow_inside")
    val HOP_WAKE_TOUCH = booleanPreferencesKey("hop_wake_touch")
    val HOP_IN_ISLAND = booleanPreferencesKey("hop_in_island")
    val HOP_ANIM = booleanPreferencesKey("hop_anim")
}

val Context.prefs: Flow<Preferences> get() = store.data

suspend fun <T> Context.save(key: Preferences.Key<T>, v: T) {
    store.edit { it[key] = v }
}

data class AppItem(val pkg: String, val label: String, val intent: Intent, val icon: ImageBitmap)

suspend fun Context.loadApps(): List<AppItem> = withContext(Dispatchers.Default) {
    val pm = packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != packageName }
        .map {
            val ai = it.activityInfo
            AppItem(
                ai.packageName,
                it.loadLabel(pm).toString(),
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(ai.packageName, ai.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
                it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()
            )
        }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

suspend fun Context.update(block: (MutablePreferences) -> Unit) {
    store.edit { block(it) }
}
