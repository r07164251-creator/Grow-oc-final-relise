package com.growoc.launcher.ui

import android.content.Intent
import android.provider.Settings
import android.text.format.DateFormat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import com.growoc.launcher.data.AppItem
import com.growoc.launcher.data.K
import com.growoc.launcher.data.save
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

enum class IslandTab { QUICK, HOME }

enum class Section(val label: String) { HOP("HOP"), GOOT("GOOT"), THEMES("Themes"), SETTINGS("Settings") }

/** Shared by the Island, GOOT and the Home screen so any of them can open a panel. */
class IslandState {
    var tab by mutableStateOf<IslandTab?>(null)
    var section by mutableStateOf(Section.HOP)
    fun toggle(t: IslandTab) { tab = if (tab == t) null else t }
    fun open(t: IslandTab, s: Section? = null) {
        tab = t
        if (s != null) section = s
    }
}

private fun DrawScope.halo(a: Float, outside: Boolean) {
    if (a < 0.01f) return
    val pad = if (outside) 36f else 0f
    drawRect(
        Brush.radialGradient(listOf(Color(0xFFFFD35A).copy(alpha = 0.5f * a), Color.Transparent), center = center, radius = size.width * 0.5f),
        topLeft = Offset(-pad, -pad), size = Size(size.width + pad * 2f, size.height + pad * 2f)
    )
}

@Composable
fun GrowIsland(st: IslandState, pr: Preferences, apps: List<AppItem>, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tab = st.tab
    var last by remember { mutableStateOf(IslandTab.QUICK) }
    LaunchedEffect(tab) { if (tab != null) last = tab }

    val bat by rememberBattery()
    val charging = bat.second
    val glowTarget = if (charging && (pr[K.HOP_CHARGE] ?: true)) (pr[K.HOP_GLOW] ?: 70) / 100f else 0f
    val glowA by animateFloatAsState(glowTarget, tween(900), label = "glow")
    val inside = pr[K.HOP_GLOW_INSIDE] ?: false
    val showHop = pr[K.HOP_IN_ISLAND] ?: true

    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth()
                .then(if (!inside) Modifier.drawBehind { halo(glowA, true) } else Modifier)
                .glass(RoundedCornerShape(32.dp))
                .then(if (inside) Modifier.drawBehind { halo(glowA, false) } else Modifier)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IslandButton("QUICK", tab == IslandTab.QUICK) { st.toggle(IslandTab.QUICK) }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                if (showHop) HopView(pr, charging, false, Modifier.size(44.dp).clickable { st.open(IslandTab.HOME, Section.HOP) })
                else Text("Grow Island", color = p.text.copy(0.45f), fontSize = 13.sp, textAlign = TextAlign.Center)
            }
            IslandButton("HOME", tab == IslandTab.HOME) { st.toggle(IslandTab.HOME) }
        }
        AnimatedVisibility(tab != null, Modifier.padding(top = 8.dp)) {
            val maxH = (LocalConfiguration.current.screenHeightDp * 0.62f).dp
            Column(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp), 0.82f)
                    .heightIn(max = maxH).verticalScroll(rememberScrollState()).padding(20.dp)
            ) {
                if ((tab ?: last) == IslandTab.QUICK) Quick() else HomePanel(st, pr, apps, charging)
            }
        }
    }
}

@Composable
private fun IslandButton(text: String, active: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier.clip(RoundedCornerShape(24.dp))
            .background(if (active) p.accent.copy(0.25f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 12.dp)
    ) {
        Text(text, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
    }
}

@Composable
private fun Quick() {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    // Updates once a minute, and only while Quick is open.
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - System.currentTimeMillis() % 60_000L + 50L)
        }
    }
    val bat by rememberBattery()
    val pattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"

    Text(now.format(DateTimeFormatter.ofPattern(pattern)), color = p.text, fontSize = 64.sp, fontWeight = FontWeight.Light)
    Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = p.text.copy(0.65f), fontSize = 16.sp)
    Row(
        Modifier.fillMaxWidth().padding(top = 16.dp).glass(RoundedCornerShape(20.dp), 0.6f).padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Battery", color = p.text)
        Text("${bat.first}%" + if (bat.second) ", charging" else "", color = p.text.copy(0.7f))
    }
    MusicCard()
}

@Composable
private fun HomePanel(st: IslandState, pr: Preferences, apps: List<AppItem>, charging: Boolean) {
    Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Section.values().forEach { s -> Chip(s.label, st.section == s) { st.section = s } }
    }
    when (st.section) {
        Section.HOP -> HopPanel(pr, charging)
        Section.GOOT -> GootPanel(pr, apps, st)
        Section.THEMES -> ThemesPanel(pr)
        Section.SETTINGS -> SettingsPanel(pr)
    }
}

@Composable
private fun ThemesPanel(pr: Preferences) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cur = pr[K.THEME] ?: "auto"
    Text("Grow Themes", color = p.text, fontWeight = FontWeight.SemiBold)
    LazyRow(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Chip("Auto", cur == "auto") { scope.launch { ctx.save(K.THEME, "auto") } } }
        items(Themes) { t -> Chip(t.name, cur == t.id) { scope.launch { ctx.save(K.THEME, t.id) } } }
    }
}

@Composable
private fun SettingsPanel(pr: Preferences) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cols = pr[K.COLUMNS] ?: 4
    val hidden = pr[K.HIDDEN] ?: emptySet()
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Grid columns", Modifier.weight(1f), color = p.text)
        Chip("−") { if (cols > 3) scope.launch { ctx.save(K.COLUMNS, cols - 1) } }
        Text("$cols", color = p.text, modifier = Modifier.padding(horizontal = 14.dp))
        Chip("+") { if (cols < 6) scope.launch { ctx.save(K.COLUMNS, cols + 1) } }
    }
    Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassButton("Set Grow OC as Home", true, {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }, Modifier.fillMaxWidth())
        GlassButton("Show setup guide again", true, {
            scope.launch { ctx.save(K.ONBOARDED, false) }
        }, Modifier.fillMaxWidth())
        if (hidden.isNotEmpty()) GlassButton("Show ${hidden.size} hidden apps", true, {
            scope.launch { ctx.save(K.HIDDEN, emptySet<String>()) }
        }, Modifier.fillMaxWidth())
    }
}
