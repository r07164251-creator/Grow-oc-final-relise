package com.growoc.launcher.assistant

enum class Cat(val label: String) {
    APPS("Apps"), FAV("Favorites"), TIME("Time and date"), MATH("Math"), TIMERS("Timers and alarms"),
    DEVICE("Device"), SEARCH("Search"), GROW("Grow OC"), CHAT("Chat")
}

class Cmd(val id: String, val cat: Cat, val phrases: List<String>) {
    val norm: List<String> by lazy { phrases.map { Norm.text(it) } }
}

/** All GOOT commands live here. Add a line to teach GOOT a new phrase (ru / uk / en). */
object CommandRegistry {
    private fun c(id: String, cat: Cat, phrases: String) = Cmd(id, cat, phrases.split("|"))

    val all: List<Cmd> = listOf(
        c("app.youtube", Cat.APPS, "открой ютуб|открой youtube|запусти ютуб|відкрий ютуб|відкрий youtube|open youtube|launch youtube"),
        c("app.spotify", Cat.APPS, "открой спотифай|открой spotify|запусти спотифай|відкрий спотіфай|відкрий spotify|open spotify|launch spotify"),
        c("app.chrome", Cat.APPS, "открой хром|открой chrome|запусти хром|відкрий хром|відкрий chrome|open chrome"),
        c("app.gallery", Cat.APPS, "открой галерею|открой фото|відкрий галерею|відкрий фото|open gallery|open photos"),
        c("app.notes", Cat.APPS, "открой заметки|открой мои заметки|відкрий нотатки|відкрий мої нотатки|open notes|open my notes"),
        c("app.settings", Cat.APPS, "открой настройки|открой системные настройки|відкрий налаштування|open settings|open system settings"),
        c("app.camera", Cat.APPS, "открой камеру|відкрий камеру|open camera|take a photo"),
        c("app.calendar", Cat.APPS, "открой календарь|відкрий календар|open calendar"),
        c("app.clock", Cat.APPS, "открой часы|открой будильники|відкрий годинник|open clock|open alarms"),
        c("app.store", Cat.APPS, "открой магазин приложений|открой плей маркет|відкрий магазин застосунків|відкрий плей маркет|open app store|open play store"),

        c("fav.blogger", Cat.FAV, "открой моего любимого блогера|открой любимого блогера|відкрий мого улюбленого блогера|open my favorite blogger|open favorite blogger"),
        c("fav.channel", Cat.FAV, "открой мой любимый канал|відкрий мій улюблений канал|open my favorite channel"),
        c("fav.site", Cat.FAV, "открой мой любимый сайт|открой любимый сайт|відкрий мій улюблений сайт|open my favorite site|open favorite website"),
        c("fav.app", Cat.FAV, "открой любимое приложение|відкрий улюблений застосунок|open my favorite app"),
        c("fav.music", Cat.FAV, "открой любимую музыку|включи любимую музыку|відкрий улюблену музику|увімкни улюблену музику|open my favorite music|play my favorite music"),

        c("time.now", Cat.TIME, "сколько времени|который час|скажи время|скільки часу|котра година|what time is it|tell me the time"),
        c("date.today", Cat.TIME, "какая сегодня дата|какое сегодня число|яка сьогодні дата|яке сьогодні число|what is the date|what is todays date"),
        c("day.today", Cat.TIME, "какой сегодня день|какой сегодня день недели|який сьогодні день|what day is it|what day is today"),
        c("date.tomorrow", Cat.TIME, "когда будет завтра|какая завтра дата|яка завтра дата|коли буде завтра|what is tomorrows date"),

        c("math", Cat.MATH, "сколько будет|посчитай|вычисли|скільки буде|порахуй|обчисли|calculate|compute|how much is"),

        c("timer.set", Cat.TIMERS, "поставь таймер|запусти таймер|постав таймер|set a timer|set timer|start a timer"),
        c("timer.cancel", Cat.TIMERS, "отмени таймер|останови таймер|скасуй таймер|cancel the timer|cancel timer"),
        c("alarm.set", Cat.TIMERS, "поставь будильник|постав будильник|set an alarm|set alarm"),
        c("stopwatch", Cat.TIMERS, "открой секундомер|відкрий секундомір|open stopwatch"),

        c("device.battery", Cat.DEVICE, "покажи уровень батареи|уровень заряда|сколько заряда|покажи рівень батареї|скільки заряду|battery level|show battery"),
        c("device.torch.on", Cat.DEVICE, "включи фонарик|включи фонарь|увімкни ліхтарик|turn on the flashlight|flashlight on"),
        c("device.torch.off", Cat.DEVICE, "выключи фонарик|выключи фонарь|вимкни ліхтарик|turn off the flashlight|flashlight off"),
        c("device.wifi", Cat.DEVICE, "открой настройки wi-fi|открой настройки вайфай|відкрий налаштування wi-fi|open wifi settings|open wi-fi settings"),
        c("device.bluetooth", Cat.DEVICE, "открой настройки bluetooth|открой настройки блютуз|відкрий налаштування bluetooth|open bluetooth settings"),
        c("device.volume", Cat.DEVICE, "покажи уровень громкости|какая громкость|покажи рівень гучності|яка гучність|show volume|volume level"),
        c("device.display", Cat.DEVICE, "открой настройки дисплея|открой настройки экрана|відкрий налаштування дисплея|open display settings"),

        c("search.web", Cat.SEARCH, "найди информацию|найди|поищи|знайди інформацію|знайди|пошукай|search for"),
        c("search.weather", Cat.SEARCH, "найди погоду|какая погода|покажи погоду|яка погода|weather|what is the weather"),
        c("search.browser", Cat.SEARCH, "открой браузер|відкрий браузер|open browser|open the browser"),

        c("grow.quick", Cat.GROW, "открой quick|открой квик|відкрий квік|open quick"),
        c("grow.home", Cat.GROW, "открой home|открой хоум|відкрий хоум|open home"),
        c("grow.island", Cat.GROW, "открой grow island|открой остров|відкрий острів|open grow island"),
        c("grow.hop", Cat.GROW, "покажи hop|покажи хоп|покажи кота|покажи хопа|show hop|show the cat"),
        c("grow.hop.wake", Cat.GROW, "разбуди hop|разбуди хоп|розбуди хоп|wake hop|wake up hop"),
        c("grow.settings", Cat.GROW, "покажи настройки|покажи налаштування|show settings|open grow settings"),
        c("grow.theme", Cat.GROW, "сменить тему|смени тему|змінити тему|зміни тему|change theme|next theme"),

        c("chat.hello", Cat.CHAT, "привет goot|привет гут|привет|привіт goot|привіт гут|привіт|hello goot|hi goot|hello"),
        c("chat.how", Cat.CHAT, "как дела|як справи|how are you"),
        c("chat.can", Cat.CHAT, "что ты умеешь|що ти вмієш|what can you do"),
        c("chat.help", Cat.CHAT, "помоги мне|помощь|допоможи мені|допомога|help me|help"),
        c("chat.list", Cat.CHAT, "покажи список команд|список команд|покажи перелік команд|перелік команд|show command list|list commands")
    )

    val phraseCount: Int get() = all.sumOf { it.phrases.size }
}
