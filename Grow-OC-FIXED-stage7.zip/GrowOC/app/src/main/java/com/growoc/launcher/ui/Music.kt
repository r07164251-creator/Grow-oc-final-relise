package com.growoc.launcher.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.growoc.launcher.media.MediaRepo
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun MusicCard() {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val s by MediaRepo.state.collectAsState()
    Column(
        Modifier.fillMaxWidth().padding(top = 12.dp).glass(RoundedCornerShape(20.dp), 0.6f).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Spotify", color = p.text, fontWeight = FontWeight.SemiBold)
        when {
            !s.access -> {
                Text(
                    "Android needs notification access to share what Spotify is playing. Grow OC only uses it for the media session.",
                    color = p.text.copy(0.65f), fontSize = 13.sp
                )
                GlassButton("Allow access", true, {
                    runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }, Modifier.fillMaxWidth())
            }
            !s.found -> {
                val installed = ctx.packageManager.getLaunchIntentForPackage(MediaRepo.SPOTIFY) != null
                Text(
                    if (installed) "Nothing is playing in Spotify." else "Spotify is not installed.",
                    color = p.text.copy(0.65f), fontSize = 13.sp
                )
                GlassButton(if (installed) "Open Spotify" else "Get Spotify", true, { openSpotify(ctx, installed) }, Modifier.fillMaxWidth())
            }
            else -> Player(s)
        }
    }
}

private fun openSpotify(ctx: Context, installed: Boolean) {
    val i = if (installed) ctx.packageManager.getLaunchIntentForPackage(MediaRepo.SPOTIFY)
    else Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + MediaRepo.SPOTIFY))
    if (i != null) runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private fun mmss(ms: Long): String {
    val t = (ms / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(t / 60L, t % 60L)
}

@Composable
private fun Player(s: MediaRepo.Snapshot) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val tr = s.track
    val art = tr?.art
    val accent = remember(art) {
        art?.let { Color(Bitmap.createScaledBitmap(it, 1, 1, true).getPixel(0, 0)) } ?: p.accent
    }
    // Ticks once a second, and only while Spotify is actually playing.
    val pos by produceState(s.positionMs, s) {
        value = s.positionMs
        while (s.playing) {
            val since = if (s.stamp > 0L) SystemClock.elapsedRealtime() - s.stamp else 0L
            value = s.positionMs + (since * s.speed).toLong()
            delay(1000)
        }
    }
    val dur = tr?.durationMs ?: 0L
    val frac = if (dur > 0L) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        if (art != null) Image(art.asImageBitmap(), null, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)))
        else Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(0.25f)))
        Column(Modifier.weight(1f)) {
            Text(tr?.title ?: "", color = p.text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(tr?.artist ?: "", color = p.text.copy(0.65f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
    if (s.playing) AnimatedWave(accent) else WaveBars(accent, { 0f }, true)
    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(p.text.copy(0.1f))) {
        Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(accent))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(mmss(pos), color = p.text.copy(0.5f), fontSize = 11.sp)
        Text(if (dur > 0L) mmss(dur) else "", color = p.text.copy(0.5f), fontSize = 11.sp)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
        Chip("Prev") { MediaRepo.previous() }
        Chip(if (s.playing) "Pause" else "Play", true) { if (s.playing) MediaRepo.pause() else MediaRepo.play() }
        Chip("Next") { MediaRepo.next() }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Lyrics are shown in Spotify.", Modifier.weight(1f), color = p.text.copy(0.5f), fontSize = 12.sp)
        Chip("Open Spotify") { openSpotify(ctx, true) }
    }
}

/** Decorative rhythm tied to the playing state. It is not an analysis of the audio. */
@Composable
private fun AnimatedWave(color: Color) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase = t.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "phase")
    WaveBars(color, { phase.value }, false)
}

@Composable
private fun WaveBars(color: Color, phase: () -> Float, flat: Boolean) {
    Canvas(Modifier.fillMaxWidth().height(28.dp)) {
        val n = 28
        val gap = size.width / n
        for (i in 0 until n) {
            val h = if (flat) 0.12f else 0.2f + 0.8f * abs(sin((phase() + i * 0.09f) * 2f * PI.toFloat()))
            drawRoundRect(
                color.copy(alpha = 0.85f),
                topLeft = Offset(i * gap + gap * 0.2f, size.height * (1f - h) / 2f),
                size = Size(gap * 0.6f, size.height * h),
                cornerRadius = CornerRadius(gap * 0.3f)
            )
        }
    }
}
