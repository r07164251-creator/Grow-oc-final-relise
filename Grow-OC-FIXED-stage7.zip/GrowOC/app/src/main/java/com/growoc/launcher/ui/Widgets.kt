package com.growoc.launcher.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.growoc.launcher.data.battery

@Composable
fun Chip(text: String, on: Boolean = false, onClick: () -> Unit) {
    val p = LocalPalette.current
    Text(
        text, color = p.text, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(16.dp))
            .background(if (on) p.accent.copy(0.3f) else p.text.copy(0.08f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = p.text, fontSize = 15.sp)
        Switch(checked, onChange)
    }
}

@Composable
fun Field(value: String, onValue: (String) -> Unit, hint: String, modifier: Modifier = Modifier, onDone: (() -> Unit)? = null) {
    val p = LocalPalette.current
    BasicTextField(
        value = value, onValueChange = onValue, singleLine = true,
        textStyle = TextStyle(color = p.text, fontSize = 15.sp),
        cursorBrush = SolidColor(p.accent),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
        modifier = modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp), 0.5f)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Text(hint, color = p.text.copy(0.4f), fontSize = 15.sp)
                inner()
            }
        }
    )
}

@Composable
fun Bar(label: String, value: Int, color: Color) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(84.dp), color = p.text.copy(0.7f), fontSize = 13.sp)
        Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(p.text.copy(0.1f))) {
            Box(Modifier.fillMaxWidth(value.coerceIn(0, 100) / 100f).fillMaxHeight().background(color))
        }
        Text("$value", Modifier.width(34.dp), color = p.text.copy(0.6f), fontSize = 12.sp, textAlign = TextAlign.End)
    }
}

/** Battery level and charging state, updated by the system broadcast while composed. */
@Composable
fun rememberBattery(): State<Pair<Int, Boolean>> {
    val ctx = LocalContext.current
    return produceState(0 to false) {
        val rec = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { i.battery()?.let { value = it } }
        }
        ctx.registerReceiver(rec, IntentFilter(Intent.ACTION_BATTERY_CHANGED)).battery()?.let { value = it }
        awaitDispose { ctx.unregisterReceiver(rec) }
    }
}
