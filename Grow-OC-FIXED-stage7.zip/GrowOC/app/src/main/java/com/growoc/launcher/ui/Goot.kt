package com.growoc.launcher.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.Preferences
import com.growoc.launcher.assistant.*
import com.growoc.launcher.data.AppItem
import com.growoc.launcher.data.K
import com.growoc.launcher.data.save
import com.growoc.launcher.data.update
import com.growoc.launcher.pet.HopStore
import kotlinx.coroutines.launch
import java.util.Locale

private fun defaultLang(): String = when (Locale.getDefault().language) {
    "uk" -> "uk-UA"
    "en" -> "en-US"
    else -> "ru-RU"
}

private fun nextTheme(cur: String?): String {
    val ids = Themes.map { it.id }
    return ids[(ids.indexOf(cur) + 1) % ids.size]
}

@Composable
fun GootPanel(pr: Preferences, apps: List<AppItem>, st: IslandState) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val lang = pr[K.GOOT_LANG] ?: defaultLang()
    var input by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var showList by remember { mutableStateOf(false) }
    var showFav by remember { mutableStateOf(false) }
    val history = History.list(pr[K.GOOT_HISTORY])

    fun exec(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        val r = GootEngine.run(Env(ctx, apps, pr, lang), q)
        reply = r.text
        input = ""
        scope.launch { ctx.save(K.GOOT_HISTORY, History.add(pr[K.GOOT_HISTORY] ?: "", q)) }
        when (r.effect) {
            Effect.QUICK -> st.open(IslandTab.QUICK)
            Effect.HOME -> st.open(IslandTab.HOME)
            Effect.HOP -> st.open(IslandTab.HOME, Section.HOP)
            Effect.SETTINGS -> st.open(IslandTab.HOME, Section.SETTINGS)
            Effect.COMMANDS -> showList = true
            Effect.WAKE_HOP -> scope.launch { HopStore.wake(ctx) }
            Effect.NEXT_THEME -> scope.launch { ctx.save(K.THEME, nextTheme(pr[K.THEME])) }
            Effect.NONE -> {}
        }
    }

    val speech = remember { Speech(ctx) }
    SideEffect {
        speech.onText = { listening = false; exec(it) }
        speech.onStatus = { reply = it; listening = false }
    }
    DisposableEffect(Unit) { onDispose { speech.destroy() } }
    val support = remember { speech.support() }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listening = speech.start(lang)
        else reply = tr(lang, "Нет доступа к микрофону. Вводите команды текстом.", "Немає доступу до мікрофона. Вводьте команди текстом.", "No microphone access. Type commands instead.")
    }
    fun mic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            listening = speech.start(lang)
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("GOOT", color = p.text, fontWeight = FontWeight.SemiBold)
        Text(
            when (support) {
                0 -> tr(lang, "Офлайн-распознавание доступно.", "Офлайн-розпізнавання доступне.", "Offline recognition is available.")
                1 -> tr(lang, "Распознавание может требовать интернет. Текстовые команды работают всегда.", "Розпізнавання може потребувати інтернет. Текстові команди працюють завжди.", "Recognition may need internet. Typed commands always work.")
                else -> tr(lang, "Распознавание речи не найдено — вводите текстом.", "Розпізнавання мови не знайдено — вводьте текстом.", "No speech recognizer — type instead.")
            },
            color = p.text.copy(0.55f), fontSize = 12.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(input, { input = it }, "Type a command", Modifier.weight(1f)) { exec(input) }
            Chip("Go") { exec(input) }
            Chip(if (listening) "Stop" else "Mic", listening) {
                if (listening) { speech.stop(); listening = false } else mic()
            }
        }
        if (reply.isNotEmpty()) {
            Text(
                reply, color = p.text, fontSize = 16.sp,
                modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp), 0.6f).padding(12.dp)
            )
        }
        if (history.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history.take(6)) { h -> Chip(h) { exec(h) } }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Commands", showList) { showList = !showList }
            Chip("Favorites", showFav) { showFav = !showFav }
        }
        if (showList) {
            CommandRegistry.all.groupBy { it.cat }.forEach { (cat, list) ->
                Text(cat.label, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                list.forEach { c ->
                    Text("• " + c.phrases.first() + " / " + c.phrases.last(), color = p.text.copy(0.6f), fontSize = 12.sp)
                }
            }
        }
        if (showFav) {
            var fb by remember(pr[K.FAV_BLOGGER]) { mutableStateOf(pr[K.FAV_BLOGGER] ?: "") }
            var fs by remember(pr[K.FAV_SITE]) { mutableStateOf(pr[K.FAV_SITE] ?: "") }
            var fa by remember(pr[K.FAV_APP]) { mutableStateOf(pr[K.FAV_APP] ?: "") }
            var fm by remember(pr[K.FAV_MUSIC]) { mutableStateOf(pr[K.FAV_MUSIC] ?: "") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("RU", lang.startsWith("ru")) { scope.launch { ctx.save(K.GOOT_LANG, "ru-RU") } }
                Chip("UK", lang.startsWith("uk")) { scope.launch { ctx.save(K.GOOT_LANG, "uk-UA") } }
                Chip("EN", lang.startsWith("en")) { scope.launch { ctx.save(K.GOOT_LANG, "en-US") } }
            }
            Field(fb, { fb = it }, "Favorite blogger or channel link")
            Field(fs, { fs = it }, "Favorite site")
            Field(fa, { fa = it }, "Favorite app (its name)")
            Field(fm, { fm = it }, "Favorite music link")
            GlassButton("Save favorites", true, {
                scope.launch {
                    ctx.update {
                        it[K.FAV_BLOGGER] = fb.trim()
                        it[K.FAV_SITE] = fs.trim()
                        it[K.FAV_APP] = fa.trim()
                        it[K.FAV_MUSIC] = fm.trim()
                    }
                }
            }, Modifier.fillMaxWidth())
        }
    }
}
