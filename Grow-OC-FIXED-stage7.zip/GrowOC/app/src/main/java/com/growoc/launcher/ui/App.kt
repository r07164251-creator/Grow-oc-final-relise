package com.growoc.launcher.ui

import android.app.role.RoleManager
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.growoc.launcher.data.*
import kotlinx.coroutines.launch

@Composable
fun GrowApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val loaded by remember { ctx.prefs }.collectAsState(initial = null)
    val pr = loaded ?: return
    val dark = isSystemInDarkTheme()
    val id = pr[K.THEME] ?: "auto"
    val palette = Themes.firstOrNull { it.id == id } ?: Themes[if (dark) 1 else 0]
    GrowTheme(palette) {
        if (pr[K.ONBOARDED] == true) Home(pr)
        else Onboarding { scope.launch { ctx.save(K.ONBOARDED, true) } }
    }
}

// ready = included in this build
private val features = listOf(
    "Strict Liquid Glass" to true, "Grow Home" to true, "Custom Wallpapers" to false,
    "Custom Widgets" to false, "Custom Themes" to true, "Custom Clock" to false,
    "Custom Fonts" to false, "Grow Island" to true, "Quick" to true, "Home" to true,
    "GOOT Voice Assistant" to false, "HOP Virtual Pet" to false, "Grow Control" to false,
    "Grow Studio" to false, "Grow Sounds" to false
)

@Composable
fun Onboarding(onFinish: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var step by remember { mutableIntStateOf(0) }
    var accepted by remember { mutableStateOf(false) }
    val roles = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    fun create() {
        try {
            val rm = ctx.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME))
                roles.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
        } catch (e: Exception) {
            runCatching {
                ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        onFinish()
    }

    Box(Modifier.fillMaxSize().background(p.bg).systemBarsPadding().padding(24.dp)) {
        Crossfade(step, label = "step") { s ->
            when (s) {
                0 -> Step("Welcome to Grow OC.", null, "Continue", accepted, { step = 1 }) {
                    InfoCard("What is Grow OC", "A Liquid Glass home screen for Android: your apps, Grow Island, themes and more.")
                    InfoCard("Permissions", "Nothing is requested up front. Each permission is asked only when a feature needs it.")
                    InfoCard("Your data", "Settings stay on this device. No account, no server.")
                    InfoCard("Make it your Home", "Next, Android will ask you to pick Grow OC as your Home app. You can repeat this later in Grow Settings.")
                    InfoCard("Terms of Use", "Grow OC is provided as is, never modifies other apps, and is used at your own risk.")
                    Row(
                        Modifier.fillMaxWidth().clickable { accepted = !accepted },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(accepted, { accepted = it })
                        Text("I accept the Terms of Use", color = p.text)
                    }
                }
                1 -> Step("Grow OC — V1 BASIC UPDATE.", "What is in this build, and what is coming.", "Continue", true, { step = 2 }) {
                    features.forEach { (name, ready) ->
                        Row(
                            Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.6f)
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(name, color = p.text, fontSize = 16.sp)
                            Text(
                                if (ready) "Ready" else "Soon",
                                color = if (ready) p.accent else p.text.copy(0.4f), fontSize = 13.sp
                            )
                        }
                    }
                }
                else -> Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        "Create your own experience.", color = p.text, fontSize = 36.sp,
                        lineHeight = 42.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
                    )
                    Text(
                        "Welcome to Grow OC. Your Android, your style.", color = p.text.copy(0.6f),
                        fontSize = 16.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 12.dp, bottom = 40.dp)
                    )
                    GlassButton("Создать систему", true, { create() }, Modifier.fillMaxWidth().padding(horizontal = 16.dp))
                    Text(
                        "Android will ask you to choose Grow OC as your Home app. If nothing appears: Settings → Apps → Default apps → Home app.",
                        color = p.text.copy(0.45f), fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun Step(
    title: String, sub: String?, button: String, enabled: Boolean,
    onNext: () -> Unit, body: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxSize()) {
        Text(title, color = p.text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
        if (sub != null) Text(sub, color = p.text.copy(0.6f), fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp))
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = body
        )
        GlassButton(button, enabled, onNext, Modifier.fillMaxWidth())
    }
}

@Composable
fun InfoCard(title: String, text: String) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp), 0.6f).padding(16.dp)) {
        Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Text(text, color = p.text.copy(0.65f), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun GlassButton(text: String, enabled: Boolean = true, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Box(
        modifier.glass(RoundedCornerShape(22.dp), if (enabled) 0.9f else 0.3f)
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 17.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = p.text.copy(if (enabled) 1f else 0.4f), fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }
}
