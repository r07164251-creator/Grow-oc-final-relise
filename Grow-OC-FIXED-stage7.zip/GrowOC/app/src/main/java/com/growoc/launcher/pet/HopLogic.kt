package com.growoc.launcher.pet

data class HopStats(val hunger: Int = 30, val energy: Int = 80, val happiness: Int = 70)

enum class HopMood { JOY, CALM, SLEEPY, PLAYFUL, IRRITATED }

/** Pure game rules for HOP. Gentle by design: HOP never "dies" and never nags. */
object HopLogic {
    private fun c(v: Int) = v.coerceIn(0, 100)

    fun mood(s: HopStats): Int = c(((100 - s.hunger) + s.energy + s.happiness) / 3)

    fun moodOf(s: HopStats): HopMood = when {
        s.energy < 30 -> HopMood.SLEEPY
        s.hunger > 75 || s.happiness < 30 -> HopMood.IRRITATED
        s.happiness >= 75 && s.energy >= 55 -> HopMood.PLAYFUL
        s.happiness >= 60 -> HopMood.JOY
        else -> HopMood.CALM
    }

    /** Drift over [minutes] (capped at 24 h). Hunger tops out at 85; energy and happiness have floors. */
    fun decay(s: HopStats, minutes: Long, sleeping: Boolean): HopStats {
        val h = minutes.coerceIn(0L, 1440L) / 60f
        val hunger = (s.hunger + h * (if (sleeping) 1f else 3f)).coerceAtMost(maxOf(s.hunger.toFloat(), 85f))
        val energy = if (sleeping) s.energy + h * 12f
        else (s.energy - h * 2f).coerceAtLeast(minOf(s.energy.toFloat(), 15f))
        val happy = (s.happiness - h * 1.5f).coerceAtLeast(minOf(s.happiness.toFloat(), 25f))
        return HopStats(c(hunger.toInt()), c(energy.toInt()), c(happy.toInt()))
    }

    fun feed(s: HopStats) = s.copy(hunger = c(s.hunger - 35), happiness = c(s.happiness + 5))

    /** Null when HOP is too tired to play. */
    fun play(s: HopStats): HopStats? =
        if (s.energy < 15) null
        else s.copy(happiness = c(s.happiness + 15), energy = c(s.energy - 12), hunger = c(s.hunger + 8))

    fun pet(s: HopStats) = s.copy(happiness = c(s.happiness + 3))

    /** Sleep window [start, wake) in hours; wraps past midnight (22 -> 7). */
    fun isSleepTime(hour: Int, start: Int, wake: Int): Boolean = when {
        start == wake -> false
        start < wake -> hour in start until wake
        else -> hour >= start || hour < wake
    }
}
