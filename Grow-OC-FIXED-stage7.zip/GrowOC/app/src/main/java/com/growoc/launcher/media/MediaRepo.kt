package com.growoc.launcher.media

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Spotify-only now-playing state, taken from the system media session. */
object MediaRepo {
    const val SPOTIFY = "com.spotify.music"

    class Track(val title: String, val artist: String, val art: Bitmap?, val durationMs: Long)

    data class Snapshot(
        val access: Boolean,            // notification access granted
        val found: Boolean,             // a Spotify session exists
        val playing: Boolean = false,
        val track: Track? = null,
        val positionMs: Long = 0L,
        val stamp: Long = 0L,           // elapsedRealtime of the last position update
        val speed: Float = 1f
    )

    private val _state = MutableStateFlow(Snapshot(access = false, found = false))
    val state: StateFlow<Snapshot> = _state

    private var controller: MediaController? = null
    private var manager: MediaSessionManager? = null

    private val listener = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }
    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { publish() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { publish() }
        override fun onSessionDestroyed() { pick(null) }
    }

    /** Safe to call often (onResume, listener connect). Must run on the main thread. */
    fun start(app: Context) {
        val ctx = app.applicationContext
        if (!NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) {
            stop()
            return
        }
        try {
            val m = ctx.getSystemService(MediaSessionManager::class.java)
            val c = ComponentName(ctx, GrowNotificationListener::class.java)
            if (manager == null) {
                m.addOnActiveSessionsChangedListener(listener, c)
                manager = m
            }
            pick(m.getActiveSessions(c))
        } catch (e: SecurityException) {
            stop()
        }
    }

    fun stop() {
        controller?.unregisterCallback(callback)
        controller = null
        manager?.removeOnActiveSessionsChangedListener(listener)
        manager = null
        _state.value = Snapshot(access = false, found = false)
    }

    private fun pick(list: List<MediaController>?) {
        val next = list?.firstOrNull { it.packageName == SPOTIFY }
        if (next?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = next
            next?.registerCallback(callback)
        }
        publish()
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            _state.value = Snapshot(access = true, found = false)
            return
        }
        val md = c.metadata
        val st = c.playbackState
        val track = md?.let {
            Track(
                it.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "",
                it.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: it.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "",
                it.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: it.getBitmap(MediaMetadata.METADATA_KEY_ART),
                it.getLong(MediaMetadata.METADATA_KEY_DURATION)
            )
        }
        _state.value = Snapshot(
            access = true, found = true,
            playing = st?.state == PlaybackState.STATE_PLAYING,
            track = track,
            positionMs = st?.position ?: 0L,
            stamp = st?.lastPositionUpdateTime ?: 0L,
            speed = st?.playbackSpeed ?: 1f
        )
    }

    fun play() { controller?.transportControls?.play() }
    fun pause() { controller?.transportControls?.pause() }
    fun next() { controller?.transportControls?.skipToNext() }
    fun previous() { controller?.transportControls?.skipToPrevious() }
}
