package com.growoc.launcher.assistant

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Push-to-talk speech input. Never listens in the background. */
class Speech(private val ctx: Context) {
    var onText: (String) -> Unit = {}
    var onStatus: (String) -> Unit = {}
    private var rec: SpeechRecognizer? = null

    /** 0 = on-device recognition confirmed, 1 = a recognizer exists (offline support unknown), 2 = none. */
    fun support(): Int = when {
        Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx) -> 0
        SpeechRecognizer.isRecognitionAvailable(ctx) -> 1
        else -> 2
    }

    fun start(lang: String): Boolean {
        if (support() == 2) { onStatus(msg(lang, "none")); return false }
        destroy()
        val r = if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx))
            SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        else SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onResults(results: Bundle?) {
                val s = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (s.isNullOrBlank()) onStatus(msg(lang, "nomatch")) else onText(s)
            }
            override fun onError(error: Int) {
                val key = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "nomatch"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> "offline"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "perm"
                    SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "pack"
                    else -> "fail"
                }
                onStatus(msg(lang, key))
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        rec = r
        r.startListening(i)
        return true
    }

    fun stop() { rec?.stopListening() }

    fun destroy() {
        rec?.destroy()
        rec = null
    }

    private fun msg(l: String, key: String): String = when (key) {
        "none" -> tr(l, "Распознавание речи не найдено. Вводите команды текстом.", "Розпізнавання мови не знайдено. Вводьте команди текстом.", "No speech recognizer found. Type commands instead.")
        "nomatch" -> tr(l, "Не расслышал. Попробуйте ещё раз.", "Не розчув. Спробуйте ще раз.", "Did not catch that. Try again.")
        "offline" -> tr(l, "Нужен интернет или офлайн-пакет языка (настройки Google → Голосовой ввод → Офлайн). Текстовые команды работают всегда.", "Потрібен інтернет або офлайн-пакет мови (налаштування Google → Голосове введення → Офлайн). Текстові команди працюють завжди.", "Needs internet or an offline language pack (Google settings → Voice → Offline). Typed commands always work.")
        "perm" -> tr(l, "Нет доступа к микрофону.", "Немає доступу до мікрофона.", "No microphone access.")
        "pack" -> tr(l, "Язык не поддерживается: установите языковой пакет или вводите текстом.", "Мова не підтримується: встановіть мовний пакет або вводьте текстом.", "Language not supported: install the language pack or type instead.")
        else -> tr(l, "Не получилось распознать. Вводите текстом.", "Не вдалося розпізнати. Вводьте текстом.", "Recognition failed. Type instead.")
    }
}
