package com.growoc.launcher.pet

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import com.growoc.launcher.data.K
import com.growoc.launcher.data.update
import java.util.Calendar

/** Reads and writes HOP's saved state. Stats are decayed lazily from the saved timestamp. */
object HopStore {
    fun sleeping(pr: Preferences, now: Long = System.currentTimeMillis()): Boolean {
        if (pr[K.HOP_SLEEP_MANUAL] == true) return true
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val window = HopLogic.isSleepTime(hour, pr[K.HOP_SLEEP_START] ?: 22, pr[K.HOP_WAKE_HOUR] ?: 7)
        return window && now > (pr[K.HOP_WOKEN_UNTIL] ?: 0L)
    }

    fun stats(pr: Preferences, now: Long = System.currentTimeMillis()): HopStats {
        val saved = HopStats(pr[K.HOP_HUNGER] ?: 30, pr[K.HOP_ENERGY] ?: 80, pr[K.HOP_HAPPY] ?: 70)
        val stamp = pr[K.HOP_STAMP] ?: now
        return HopLogic.decay(saved, (now - stamp) / 60_000L, sleeping(pr, now))
    }

    suspend fun put(ctx: Context, s: HopStats) {
        ctx.update {
            it[K.HOP_HUNGER] = s.hunger
            it[K.HOP_ENERGY] = s.energy
            it[K.HOP_HAPPY] = s.happiness
            it[K.HOP_STAMP] = System.currentTimeMillis()
        }
    }

    /** Wakes HOP; during a scheduled sleep window it stays up for 30 minutes. */
    suspend fun wake(ctx: Context) {
        ctx.update {
            it[K.HOP_SLEEP_MANUAL] = false
            it[K.HOP_WOKEN_UNTIL] = System.currentTimeMillis() + 30L * 60_000L
        }
    }
}
