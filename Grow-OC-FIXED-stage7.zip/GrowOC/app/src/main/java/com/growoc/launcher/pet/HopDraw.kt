package com.growoc.launcher.pet

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private const val PI_F = 3.1415927f

enum class HopAct { IDLE, SLEEP, WAKE, JUMP, WALK, STRETCH, PLAY, HAPPY, TIRED, ANNOYED }

/** Seconds a one-shot animation lasts; 0 for states that hold until the mood changes. */
fun HopAct.duration(): Float = when (this) {
    HopAct.WAKE -> 1.4f
    HopAct.JUMP -> 0.75f
    HopAct.WALK -> 3f
    HopAct.STRETCH -> 1.6f
    HopAct.PLAY -> 4f
    HopAct.HAPPY -> 1.4f
    else -> 0f
}

enum class HopColor(val label: String, val main: Color, val light: Color) {
    GINGER("Ginger", Color(0xFFE9893B), Color(0xFFFFF6EC)),
    CREAM("Cream", Color(0xFFF1D3A5), Color(0xFFFFFBF5)),
    SILVER("Silver", Color(0xFF9EA4AB), Color(0xFFF7F7F8))
}

class Pose {
    var dx = 0f; var dy = 0f; var sx = 1f; var sy = 1f; var tilt = 0f; var headDy = 0f
    var eye = 1f; var happy = false; var brows = false; var mouth = 0f; var earBack = 0f
    var tail = 0f; var flip = false; var leg = 0f; var zzz = false; var hearts = -1f
    var ballX = -1f; var ballY = 0f; var look = 0f; var glow = 0f
}

private fun stretch(p: Pose, c: Float) {
    p.sy *= 1f - 0.2f * c
    p.sx *= 1f + 0.12f * c
    p.headDy += 7f * c
    p.tilt -= 5f * c
    p.eye *= 1f - 0.45f * c
    p.tail *= 1f - 0.7f * c
}

/** t = seconds since start, a = seconds since this animation began, charge = 0..1 charging blend. */
fun hopPose(act: HopAct, t: Float, a: Float, blink: Boolean, charge: Float): Pose {
    val p = Pose()
    val b = sin(t * 2f)
    p.sy = 1f + 0.015f * b
    p.sx = 1f - 0.008f * b
    p.tail = 8f * sin(t * 1.7f)
    p.eye = if (blink) 0.08f else 1f
    when (act) {
        HopAct.IDLE -> {}
        HopAct.SLEEP -> {
            p.eye = 0f; p.headDy = 5f; p.tilt = -3f; p.tail = 0f
            p.sy = 0.93f + 0.012f * sin(t * 1.2f); p.zzz = true
        }
        HopAct.WAKE -> {
            val u = (a / 1.4f).coerceIn(0f, 1f)
            val s = sin(PI_F * u)
            p.sy = 1f + 0.12f * s; p.sx = 1f - 0.05f * s; p.mouth = s
            p.eye = if (u < 0.3f) 0.2f else 1f
        }
        HopAct.JUMP -> {
            val u = (a / 0.75f).coerceIn(0f, 1f)
            p.dy = -30f * 4f * u * (1f - u)
            p.sy = when { u < 0.15f -> 0.86f; u > 0.85f -> 0.9f; else -> 1.07f }
            p.sx = 2f - p.sy
        }
        HopAct.WALK -> {
            val u = (a / 3f).coerceIn(0f, 1f)
            p.dx = 16f * sin(2f * PI_F * u)
            p.flip = cos(2f * PI_F * u) < 0f
            val step = sin(a * 9f)
            p.dy = -abs(step) * 2.5f; p.tilt = 3f * step; p.leg = step
        }
        HopAct.STRETCH -> stretch(p, sin(PI_F * (a / 1.6f).coerceIn(0f, 1f)))
        HopAct.PLAY -> {
            p.ballX = 50f + 24f * sin(a * 2.2f)
            p.ballY = 88f - 26f * abs(sin(a * 4.4f))
            p.look = ((p.ballX - 50f) / 24f).coerceIn(-1f, 1f)
            p.mouth = 0.25f; p.leg = sin(a * 5f)
        }
        HopAct.HAPPY -> {
            val u = (a / 1.4f).coerceIn(0f, 1f)
            p.happy = true; p.mouth = 0.6f; p.hearts = u
            p.dy = -4f * abs(sin(u * 18f)) * (1f - u)
        }
        HopAct.TIRED -> {
            p.eye = 0.35f; p.headDy = 4f
            p.sy = 0.97f + 0.01f * sin(t * 1.3f); p.tail = 3f * sin(t)
        }
        HopAct.ANNOYED -> {
            p.brows = true; p.earBack = 1f; p.eye = 0.8f; p.tail = 25f * sin(t * 7f)
        }
    }
    if (charge > 0f) {
        stretch(p, charge)
        p.glow = charge
    }
    return p
}

private val Ink = Color(0xFF2A2A2E)
private val Pink = Color(0xFFF3A5A5)
private val Sun = Color(0xFFFFD35A)

fun DrawScope.drawHop(c: HopColor, p: Pose, glowK: Float, t: Float) {
    val s = size.minDimension / 100f
    withTransform({
        translate((size.width - 100f * s) / 2f, (size.height - 100f * s) / 2f)
        scale(s, s, Offset.Zero)
    }) {
        if (p.glow > 0.01f) glow(p.glow * glowK, t)
        drawOval(Color.Black.copy(alpha = 0.16f), Offset(30f + p.dx, 90f), Size(40f, 6f))
        withTransform({
            translate(p.dx, p.dy)
            if (p.flip) scale(-1f, 1f, Offset(50f, 50f))
            rotate(p.tilt, Offset(50f, 90f))
            scale(p.sx, p.sy, Offset(50f, 90f))
        }) {
            body(c, p)
            head(c, p)
        }
        if (p.ballX >= 0f) {
            drawCircle(Color(0xFFE5533D), 5f, Offset(p.ballX, p.ballY))
            drawCircle(Color.White.copy(alpha = 0.6f), 1.2f, Offset(p.ballX - 1.5f, p.ballY - 1.8f))
        }
        if (p.hearts >= 0f) hearts(p.hearts)
        if (p.zzz) zzz(t)
    }
}

private fun DrawScope.glow(a: Float, t: Float) {
    drawCircle(
        Brush.radialGradient(listOf(Sun.copy(alpha = 0.6f * a), Color.Transparent), center = Offset(50f, 45f), radius = 58f),
        radius = 58f, center = Offset(50f, 45f)
    )
    for (i in 0 until 8) {
        val ang = t * 0.3f + i * (PI_F / 4f)
        drawLine(
            Sun.copy(alpha = 0.7f * a),
            Offset(50f + 40f * cos(ang), 45f + 40f * sin(ang)),
            Offset(50f + 48f * cos(ang), 45f + 48f * sin(ang)),
            strokeWidth = 2f, cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.body(c: HopColor, p: Pose) {
    drawArc(
        c.main, startAngle = -30f + p.tail, sweepAngle = 160f, useCenter = false,
        topLeft = Offset(60f, 54f), size = Size(30f, 34f), style = Stroke(width = 6f, cap = StrokeCap.Round)
    )
    drawOval(c.main, Offset(26f, 56f), Size(48f, 36f))
    drawOval(c.light, Offset(37f, 66f), Size(26f, 24f))
    val l = 3f * p.leg
    drawOval(c.light, Offset(33f, 86f - max(0f, l)), Size(13f, 7f))
    drawOval(c.light, Offset(54f, 86f + min(0f, l)), Size(13f, 7f))
}

private fun DrawScope.head(c: HopColor, p: Pose) {
    withTransform({ translate(0f, p.headDy) }) {
        val tipX = 33f - 5f * p.earBack
        val tipY = 5f + 8f * p.earBack
        val left = Path().apply { moveTo(27f, 26f); lineTo(tipX, tipY); lineTo(46f, 17f); close() }
        val right = Path().apply { moveTo(73f, 26f); lineTo(100f - tipX, tipY); lineTo(54f, 17f); close() }
        drawPath(left, c.main)
        drawPath(right, c.main)
        drawPath(Path().apply { moveTo(31f, 23f); lineTo(tipX + 1.5f, tipY + 6f); lineTo(42f, 19f); close() }, Pink)
        drawPath(Path().apply { moveTo(69f, 23f); lineTo(98.5f - tipX, tipY + 6f); lineTo(58f, 19f); close() }, Pink)
        drawCircle(c.main, 24f, Offset(50f, 40f))
        drawOval(c.light, Offset(38f, 43f), Size(24f, 17f))
        if (p.happy) {
            drawCircle(Pink, 4f, Offset(33f, 49f), alpha = 0.5f)
            drawCircle(Pink, 4f, Offset(67f, 49f), alpha = 0.5f)
        }
        val round = Stroke(width = 1.9f, cap = StrokeCap.Round)
        for (x in floatArrayOf(40f, 60f)) {
            when {
                p.happy -> drawArc(Ink, 200f, 140f, false, Offset(x - 4f, 38f), Size(8f, 7f), style = round)
                p.eye < 0.15f -> drawArc(Ink, 20f, 140f, false, Offset(x - 4f, 38f), Size(8f, 6f), style = round)
                else -> {
                    val h = 9f * p.eye
                    drawOval(Ink, Offset(x - 3.2f + p.look * 1.8f, 41f - h / 2f), Size(6.4f, h))
                    if (p.eye > 0.6f) drawCircle(Color.White, 1.1f, Offset(x + p.look * 1.8f + 1f, 39f))
                }
            }
        }
        if (p.brows) {
            drawLine(Ink, Offset(34f, 32f), Offset(44f, 36f), strokeWidth = 2f, cap = StrokeCap.Round)
            drawLine(Ink, Offset(66f, 32f), Offset(56f, 36f), strokeWidth = 2f, cap = StrokeCap.Round)
        }
        drawPath(Path().apply { moveTo(47.2f, 46.5f); lineTo(52.8f, 46.5f); lineTo(50f, 49.8f); close() }, Pink)
        val thin = Stroke(width = 1.2f, cap = StrokeCap.Round)
        when {
            p.mouth > 0.1f -> drawOval(Ink, Offset(46.5f, 50f), Size(7f, 7f * p.mouth))
            p.brows -> drawLine(Ink, Offset(46f, 52f), Offset(54f, 52f), strokeWidth = 1.2f, cap = StrokeCap.Round)
            else -> {
                drawArc(Ink, 15f, 150f, false, Offset(44.5f, 48.5f), Size(5.5f, 5f), style = thin)
                drawArc(Ink, 15f, 150f, false, Offset(50f, 48.5f), Size(5.5f, 5f), style = thin)
            }
        }
        for (i in 0 until 3) {
            drawLine(Ink.copy(alpha = 0.35f), Offset(38f, 47f + i * 2.5f), Offset(25f, 44f + i * 4f), strokeWidth = 0.9f)
            drawLine(Ink.copy(alpha = 0.35f), Offset(62f, 47f + i * 2.5f), Offset(75f, 44f + i * 4f), strokeWidth = 0.9f)
        }
    }
}

private fun DrawScope.heart(cx: Float, cy: Float, r: Float, col: Color) {
    drawCircle(col, r, Offset(cx - r * 0.6f, cy))
    drawCircle(col, r, Offset(cx + r * 0.6f, cy))
    drawPath(
        Path().apply { moveTo(cx - r * 1.5f, cy + r * 0.3f); lineTo(cx + r * 1.5f, cy + r * 0.3f); lineTo(cx, cy + r * 2.1f); close() },
        col
    )
}

private fun DrawScope.hearts(u: Float) {
    for (i in 0 until 3) {
        val k = (u + i * 0.2f).coerceIn(0f, 1f)
        heart(40f + i * 10f, 24f - 18f * k, 2.2f, Color(0xFFE8506A).copy(alpha = 1f - k))
    }
}

private fun DrawScope.zzz(t: Float) {
    for (i in 0 until 3) {
        val u = (t * 0.5f + i / 3f) % 1f
        val x = 66f + i * 5f + u * 6f
        val y = 28f - u * 20f
        val z = 3f + i * 1.5f
        val path = Path().apply { moveTo(x, y); lineTo(x + z, y); lineTo(x, y + z); lineTo(x + z, y + z) }
        drawPath(path, Ink.copy(alpha = 0.6f * (1f - u)), style = Stroke(width = 1.2f, cap = StrokeCap.Round))
    }
}
