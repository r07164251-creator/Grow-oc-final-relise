package com.growoc.launcher.data

import android.content.Intent
import android.os.BatteryManager

/** Level (0-100) and charging state read from the sticky battery intent. */
fun Intent?.battery(): Pair<Int, Boolean>? {
    if (this == null) return null
    val level = getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    val st = getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    if (level < 0 || scale <= 0) return null
    return (level * 100 / scale) to
        (st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
}
