package com.growoc.launcher.assistant

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.format.DateFormat
import androidx.datastore.preferences.core.Preferences
import com.growoc.launcher.data.AppItem
import com.growoc.launcher.data.K
import com.growoc.launcher.data.battery
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.format.TextStyle
import java.util.Locale

/** What the UI should do after a command (open a panel, change theme, wake HOP). */
enum class Effect { NONE, QUICK, HOME, HOP, COMMANDS, SETTINGS, NEXT_THEME, WAKE_HOP }

class Reply(val text: String, val effect: Effect = Effect.NONE)

class Env(val ctx: Context, val apps: List<AppItem>, val pr: Preferences, val lang: String)

object GootEngine {
    fun run(env: Env, text: String): Reply {
        val p = GootParser.parse(text)
        val l = env.lang
        val c = env.ctx
        return when (p.id) {
            null -> Reply(tr(l, "Не понял. Скажите «покажи список команд».", "Не зрозумів. Скажіть «покажи перелік команд».", "Not understood. Try “show command list”."))
            "app.youtube" -> app(env, "youtube", "com.google.android.youtube")
            "app.spotify" -> app(env, "spotify", "com.spotify.music")
            "app.chrome" -> app(env, "chrome", "com.android.chrome")
            "app.gallery" -> app(env, "gallery|photos|галере|фото", "com.google.android.apps.photos")
            "app.notes" -> app(env, "notes|keep|заметк|нотатк", "com.google.android.keep")
            "app.store" -> app(env, "play store|google play", "com.android.vending")
            "app.open" -> app(env, p.arg, "")
            "app.settings" -> go(env, Intent(Settings.ACTION_SETTINGS))
            "app.camera" -> go(env, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "app.calendar" -> go(env, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR))
            "app.clock", "stopwatch" -> go(env, Intent(AlarmClock.ACTION_SHOW_ALARMS))
            "search.browser" -> go(env, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER))

            "fav.blogger", "fav.channel" -> fav(env, env.pr[K.FAV_BLOGGER])
            "fav.site" -> fav(env, env.pr[K.FAV_SITE])
            "fav.music" -> fav(env, env.pr[K.FAV_MUSIC])
            "fav.app" -> {
                val name = env.pr[K.FAV_APP]
                if (name.isNullOrBlank()) favEmpty(env) else app(env, name, "")
            }

            "time.now" -> Reply(
                LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern(if (DateFormat.is24HourFormat(c)) "HH:mm" else "h:mm a", Locale.forLanguageTag(l))
                )
            )
            "date.today" -> Reply(fullDate(LocalDateTime.now(), l))
            "day.today" -> Reply(LocalDateTime.now().dayOfWeek.getDisplayName(TextStyle.FULL, Locale.forLanguageTag(l)))
            "date.tomorrow" -> Reply(fullDate(LocalDateTime.now().plusDays(1), l))

            "math" -> {
                val v = GootParser.mathValue(p.arg)
                if (v == null) Reply(tr(l, "Не получилось посчитать.", "Не вдалося порахувати.", "Could not calculate that."))
                else Reply(p.arg + " = " + Calc.fmt(v))
            }

            "timer.set" -> {
                val s = GootParser.seconds(p.arg)
                if (s == null) go(env, Intent(AlarmClock.ACTION_SET_TIMER))
                else go(
                    env,
                    Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s.coerceIn(1, 86400))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                    tr(l, "Таймер", "Таймер", "Timer") + " " + mmss(s)
                )
            }
            "timer.cancel" -> go(
                env, Intent(AlarmClock.ACTION_SHOW_TIMERS),
                tr(l, "Открыл таймеры — отмените нужный.", "Відкрив таймери — скасуйте потрібний.", "Opened timers — cancel it there.")
            )
            "alarm.set" -> {
                val hm = GootParser.clock(p.arg)
                if (hm == null) go(env, Intent(AlarmClock.ACTION_SET_ALARM))
                else go(
                    env,
                    Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hm.first)
                        .putExtra(AlarmClock.EXTRA_MINUTES, hm.second).putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                    tr(l, "Будильник", "Будильник", "Alarm") + " %02d:%02d".format(hm.first, hm.second)
                )
            }

            "device.battery" -> {
                val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)).battery()
                if (b == null) Reply("—")
                else Reply("${b.first}%" + if (b.second) tr(l, ", идёт зарядка", ", триває зарядка", ", charging") else "")
            }
            "device.torch.on" -> torch(env, true)
            "device.torch.off" -> torch(env, false)
            "device.wifi" -> go(env, Intent(Settings.Panel.ACTION_WIFI))
            "device.bluetooth" -> go(env, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "device.display" -> go(env, Intent(Settings.ACTION_DISPLAY_SETTINGS))
            "device.volume" -> {
                val am = c.getSystemService(AudioManager::class.java)
                val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                Reply("$cur / $max (${cur * 100 / max}%)")
            }

            "search.web" ->
                if (p.arg.isBlank()) Reply(tr(l, "Что искать?", "Що шукати?", "What should I search for?"))
                else search(env, p.arg)
            "search.weather" -> search(env, tr(l, "погода", "погода", "weather"))

            "grow.quick" -> Reply("Quick", Effect.QUICK)
            "grow.home", "grow.island" -> Reply("Home", Effect.HOME)
            "grow.hop" -> Reply("HOP", Effect.HOP)
            "grow.hop.wake" -> Reply("HOP", Effect.WAKE_HOP)
            "grow.settings" -> Reply(tr(l, "Настройки", "Налаштування", "Settings"), Effect.SETTINGS)
            "grow.theme" -> Reply(tr(l, "Тема сменена", "Тему змінено", "Theme changed"), Effect.NEXT_THEME)

            "chat.hello" -> Reply(tr(l, "Привет! Я GOOT. Спросите время, посчитайте что-нибудь или откройте приложение.", "Привіт! Я GOOT. Запитайте час, порахуйте щось або відкрийте застосунок.", "Hi, I am GOOT. Ask the time, do some math or open an app."))
            "chat.how" -> Reply(tr(l, "Всё хорошо. Чем помочь?", "Усе добре. Чим допомогти?", "All good. How can I help?"))
            "chat.can" -> Reply(tr(l, "Открываю приложения, считаю, говорю время и дату, ставлю таймеры и будильники, включаю фонарик, ищу в интернете.", "Відкриваю застосунки, рахую, кажу час і дату, ставлю таймери та будильники, вмикаю ліхтарик, шукаю в інтернеті.", "I open apps, calculate, tell time and date, set timers and alarms, switch the flashlight and search the web."))
            "chat.help", "chat.list" -> Reply(tr(l, "Вот команды.", "Ось команди.", "Here are the commands."), Effect.COMMANDS)
            else -> Reply(tr(l, "Не понял.", "Не зрозумів.", "Not understood."))
        }
    }

    private fun mmss(sec: Int) = "%d:%02d".format(sec / 60, sec % 60)

    private fun fullDate(d: LocalDateTime, l: String): String =
        d.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale.forLanguageTag(l)))

    private fun tryGo(env: Env, i: Intent): Boolean = try {
        env.ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    private fun go(env: Env, i: Intent, ok: String = "→"): Reply =
        if (tryGo(env, i)) Reply(ok)
        else Reply(tr(env.lang, "Не получилось открыть.", "Не вдалося відкрити.", "Could not open that."))

    private fun app(env: Env, keys: String, pkg: String): Reply {
        val ks = keys.split('|').map { Norm.text(it) }.filter { it.isNotBlank() }
        val hit = ks.firstNotNullOfOrNull { k -> env.apps.firstOrNull { Norm.text(it.label) == k } }
            ?: ks.firstNotNullOfOrNull { k -> env.apps.firstOrNull { Norm.text(it.label).contains(k) } }
        val i = hit?.intent ?: if (pkg.isNotEmpty()) env.ctx.packageManager.getLaunchIntentForPackage(pkg) else null
        return if (i != null) go(env, i, "→ " + (hit?.label ?: pkg))
        else Reply(tr(env.lang, "Приложение не найдено: $keys", "Застосунок не знайдено: $keys", "App not found: $keys"))
    }

    private fun favEmpty(env: Env) = Reply(
        tr(env.lang, "Сначала задайте избранное: Home → GOOT → Favorites.", "Спочатку задайте обране: Home → GOOT → Favorites.", "Set your favorites first: Home → GOOT → Favorites.")
    )

    private fun fav(env: Env, url: String?): Reply {
        if (url.isNullOrBlank()) return favEmpty(env)
        val u = if (url.startsWith("http")) url else "https://$url"
        return go(env, Intent(Intent.ACTION_VIEW, Uri.parse(u)), "→ $url")
    }

    private fun online(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        return caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    private fun search(env: Env, q: String): Reply {
        if (!online(env.ctx)) {
            return Reply(tr(env.lang, "Нет интернета: поиск недоступен.", "Немає інтернету: пошук недоступний.", "No internet: search is unavailable."))
        }
        val a = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        val b = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
        return if (tryGo(env, a) || tryGo(env, b)) Reply("→ $q")
        else Reply(tr(env.lang, "Не получилось открыть поиск.", "Не вдалося відкрити пошук.", "Could not open search."))
    }

    private fun torch(env: Env, on: Boolean): Reply {
        val none = Reply(tr(env.lang, "Фонарик недоступен на этом устройстве.", "Ліхтарик недоступний на цьому пристрої.", "Flashlight is not available on this device."))
        return try {
            val cm = env.ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) none
            else {
                cm.setTorchMode(id, on)
                Reply(
                    if (on) tr(env.lang, "Фонарик включён", "Ліхтарик увімкнено", "Flashlight on")
                    else tr(env.lang, "Фонарик выключен", "Ліхтарик вимкнено", "Flashlight off")
                )
            }
        } catch (e: Exception) {
            none
        }
    }
}
