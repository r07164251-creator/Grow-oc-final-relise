package com.growoc.launcher.assistant

import java.util.Locale
import kotlin.math.abs

/** Safe arithmetic: + - * / ^ ( ) unary minus and postfix %. No eval, no scripting. */
object Calc {
    fun eval(src: String): Double? = try {
        val r = Parser(src.replace(',', '.').replace(" ", "")).run()
        if (r.isNaN() || r.isInfinite()) null else r
    } catch (e: Exception) {
        null
    }

    fun fmt(d: Double): String =
        if (d == Math.rint(d) && abs(d) < 1e15) d.toLong().toString()
        else String.format(Locale.US, "%.6f", d).trimEnd('0').trimEnd('.')

    private class Parser(val s: String) {
        var i = 0
        fun run(): Double {
            val v = expr()
            if (i != s.length) error("unexpected input")
            return v
        }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = power()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val r = power()
                v = if (op == '*') v * r else v / r
            }
            return v
        }
        fun power(): Double {
            val b = unary()
            return if (i < s.length && s[i] == '^') { i++; Math.pow(b, power()) } else b
        }
        fun unary(): Double = when {
            i < s.length && s[i] == '-' -> { i++; -unary() }
            i < s.length && s[i] == '+' -> { i++; unary() }
            else -> postfix()
        }
        fun postfix(): Double {
            var v = atom()
            while (i < s.length && s[i] == '%') { i++; v /= 100.0 }
            return v
        }
        fun atom(): Double {
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') error("missing )")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) error("number expected")
            return s.substring(st, i).toDouble()
        }
    }
}
