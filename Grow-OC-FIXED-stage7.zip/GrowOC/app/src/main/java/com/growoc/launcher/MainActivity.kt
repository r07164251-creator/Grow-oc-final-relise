package com.growoc.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.growoc.launcher.media.MediaRepo
import com.growoc.launcher.ui.GrowApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { GrowApp() }
    }

    override fun onResume() {
        super.onResume()
        MediaRepo.start(this) // picks up Spotify after the user grants notification access
    }
}
