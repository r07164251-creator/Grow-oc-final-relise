package com.growoc.launcher

import com.growoc.launcher.assistant.Calc
import com.growoc.launcher.assistant.CommandRegistry
import com.growoc.launcher.assistant.GootParser
import com.growoc.launcher.assistant.History
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CalcTest {
    @Test fun basics() {
        assertEquals(4.0, Calc.eval("2+2")!!, 1e-9)
        assertEquals(315.0, Calc.eval("45*7")!!, 1e-9)
        assertEquals(25.0, Calc.eval("100/4")!!, 1e-9)
        assertEquals(20.0, Calc.eval("(2+3)*4")!!, 1e-9)
        assertEquals(8.0, Calc.eval("2^3")!!, 1e-9)
    }

    @Test fun rejectsBadInput() {
        assertNull(Calc.eval("2+"))
        assertNull(Calc.eval("1/0"))
        assertNull(Calc.eval("abc"))
    }
}

class GootParserTest {
    @Test fun opensApps() {
        assertEquals("app.youtube", GootParser.parse("Открой ютуб").id)
        assertEquals("app.youtube", GootParser.parse("відкрий ютуб").id)
        assertEquals("app.spotify", GootParser.parse("open Spotify").id)
    }

    @Test fun spokenMath() {
        assertEquals(4.0, GootParser.mathValue("два плюс два")!!, 1e-9)
        assertEquals(315.0, GootParser.mathValue("45 умножить на 7")!!, 1e-9)
        assertEquals(25.0, GootParser.mathValue("100 разделить на 4")!!, 1e-9)
        assertEquals(100.0, GootParser.mathValue("20 процентов от 500")!!, 1e-9)
        assertEquals("math", GootParser.parse("Сколько будет два плюс два?").id)
    }

    @Test fun timersAndSearch() {
        assertEquals("timer.set", GootParser.parse("поставь таймер на 10 минут").id)
        assertEquals(600, GootParser.seconds("на десять минут"))
        assertEquals(90, GootParser.seconds("1 минута 30 секунд"))
        val s = GootParser.parse("найди minecraft")
        assertEquals("search.web", s.id)
        assertEquals("minecraft", s.arg)
        assertEquals("search.weather", GootParser.parse("найди погоду").id)
    }

    @Test fun unknownAndGreeting() {
        assertNull(GootParser.parse("абракадабра").id)
        assertEquals("chat.hello", GootParser.parse("Привет, GOOT!").id)
    }

    @Test fun registryIsHealthy() {
        assertTrue(CommandRegistry.phraseCount >= 100)
        assertEquals(CommandRegistry.all.size, CommandRegistry.all.map { it.id }.toSet().size)
    }

    @Test fun historyKeepsNewestFirstWithoutDuplicates() {
        assertEquals("b\na", History.add("a\nb", "b"))
    }
}
