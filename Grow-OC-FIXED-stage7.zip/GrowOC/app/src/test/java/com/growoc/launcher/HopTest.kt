package com.growoc.launcher

import com.growoc.launcher.pet.HopLogic
import com.growoc.launcher.pet.HopStats
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HopLogicTest {
    @Test fun feedingReducesHunger() {
        assertTrue(HopLogic.feed(HopStats(hunger = 80)).hunger < 80)
    }

    @Test fun playNeedsEnergy() {
        assertNull(HopLogic.play(HopStats(energy = 10)))
        assertNotNull(HopLogic.play(HopStats(energy = 60)))
    }

    @Test fun sleepWindowWrapsMidnight() {
        assertTrue(HopLogic.isSleepTime(23, 22, 7))
        assertTrue(HopLogic.isSleepTime(3, 22, 7))
        assertFalse(HopLogic.isSleepTime(12, 22, 7))
        assertFalse(HopLogic.isSleepTime(7, 22, 7))
    }

    @Test fun decayStaysGentle() {
        val s = HopLogic.decay(HopStats(), 10_000L, false)
        assertTrue(s.energy >= 15 && s.happiness >= 25 && s.hunger <= 85)
    }

    @Test fun sleepRestoresEnergy() {
        assertTrue(HopLogic.decay(HopStats(energy = 20), 300L, true).energy > 20)
    }

    @Test fun moodStaysInRange() {
        assertTrue(HopLogic.mood(HopStats(100, 0, 0)) in 0..100)
        assertTrue(HopLogic.mood(HopStats(0, 100, 100)) in 0..100)
    }
}
