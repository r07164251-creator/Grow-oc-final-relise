# Grow OC — V1 BASIC UPDATE
Package: com.growoc.launcher. Min Android 10 (API 29), target 34.
Toolchain: Gradle 8.9, Android Gradle Plugin 8.5.2, Kotlin 2.0.20, JDK 17.

## Build
    ./gradlew assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk

IMPORTANT: gradle/wrapper/gradle-wrapper.jar is a binary that could not be generated
offline. If it is missing, create it once with an installed Gradle:
    gradle wrapper --gradle-version 8.9
The GitHub workflow (.github/workflows/android.yml) does this automatically when the jar is absent.

## Install on Redmi Note 15 4G
1. Copy app-debug.apk to the phone and install it (allow "install unknown apps").
2. Open Grow OC, accept the terms, tap "Создать систему", choose Grow OC as Home app.
   If MIUI hides the dialog: Settings > Apps > Default apps > Home app.

## Permissions
None are requested at install. Voice input asks for RECORD_AUDIO only when the mic is used;
Spotify card needs the user to enable Notification access manually.
